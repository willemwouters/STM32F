#ifndef __HTTP_PROCESS_H
#define __HTTP_PROCESS_H

void http_init(void);
void http_tick(void);
void stop_http_server(void);

#endif
